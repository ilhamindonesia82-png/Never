package id.kalkulator.app;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int COLOR_BG = 0xFF121212;
    private static final int COLOR_DIGIT = 0xFF2A2A2E;
    private static final int COLOR_FUNC = 0xFF4A4A50;
    private static final int COLOR_OP = 0xFFFF9F0A;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_MUTED = 0xFF9A9AA0;
    private static final int COLOR_ERROR = 0xFFFF6B6B;
    private static final int MAX_LENGTH = 60;

    // Kunci internal (dikirim saat tombol ditekan) dan teks yang tampil di tombol.
    private static final String[][] KEYS = {
            {"C", "DEL", "%", "/"},
            {"7", "8", "9", "*"},
            {"4", "5", "6", "-"},
            {"1", "2", "3", "+"},
            {"NEG", "0", ".", "="}
    };
    private static final String[][] LABELS = {
            {"C", "⌫", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"±", "0", ",", "="}
    };

    private final StringBuilder expr = new StringBuilder();
    private boolean justEvaluated = false;
    private String error = null;

    private TextView exprView;
    private TextView previewView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(COLOR_BG);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        // Area layar
        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.BOTTOM | Gravity.END);
        display.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(display, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 2f));

        exprView = new TextView(this);
        exprView.setTextColor(COLOR_TEXT);
        exprView.setGravity(Gravity.BOTTOM | Gravity.END);
        exprView.setMaxLines(2);
        exprView.setAutoSizeTextTypeUniformWithConfiguration(
                26, 60, 2, TypedValue.COMPLEX_UNIT_SP);
        display.addView(exprView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        previewView = new TextView(this);
        previewView.setTextColor(COLOR_MUTED);
        previewView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        previewView.setGravity(Gravity.END);
        previewView.setSingleLine(true);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        previewParams.topMargin = dp(6);
        display.addView(previewView, previewParams);

        // Papan tombol
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        root.addView(pad, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 3.4f));

        for (int r = 0; r < KEYS.length; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            pad.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            for (int c = 0; c < KEYS[r].length; c++) {
                row.addView(makeButton(KEYS[r][c], LABELS[r][c], r, c));
            }
        }

        setContentView(root);

        if (savedInstanceState != null) {
            String saved = savedInstanceState.getString("expr", "");
            expr.append(saved);
            justEvaluated = savedInstanceState.getBoolean("justEvaluated", false);
        }
        refresh();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("expr", expr.toString());
        outState.putBoolean("justEvaluated", justEvaluated);
    }

    private Button makeButton(final String key, String label, int row, int col) {
        int fill;
        if (col == 3 || key.equals("=")) {
            fill = COLOR_OP;
        } else if (row == 0 || key.equals("NEG")) {
            fill = COLOR_FUNC;
        } else {
            fill = COLOR_DIGIT;
        }

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(dp(22));
        shape.setColor(fill);

        GradientDrawable mask = new GradientDrawable();
        mask.setShape(GradientDrawable.RECTANGLE);
        mask.setCornerRadius(dp(22));
        mask.setColor(0xFFFFFFFF);

        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(COLOR_TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        b.setStateListAnimator(null);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), shape, mask));
        b.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            onKey(key);
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        b.setLayoutParams(lp);
        return b;
    }

    // ---------------------------------------------------------------- logika input

    private void onKey(String k) {
        if (error != null) {
            error = null;
            expr.setLength(0);
            justEvaluated = false;
        }

        switch (k) {
            case "C":
                expr.setLength(0);
                justEvaluated = false;
                break;
            case "DEL":
                if (justEvaluated) {
                    expr.setLength(0);
                    justEvaluated = false;
                } else if (expr.length() > 0) {
                    expr.setLength(expr.length() - 1);
                }
                break;
            case "=":
                evaluate();
                break;
            case "%":
                if (expr.length() > 0 && (isDigit(last()) || last() == '%')) {
                    append("%");
                }
                break;
            case "NEG":
                negate();
                break;
            case ".":
                inputDot();
                break;
            case "+":
            case "-":
            case "*":
            case "/":
                inputOperator(k.charAt(0));
                break;
            default:
                inputDigit(k.charAt(0));
                break;
        }
        refresh();
    }

    private void inputDigit(char d) {
        if (justEvaluated) {
            expr.setLength(0);
            justEvaluated = false;
        }
        if (expr.length() > 0 && last() == '%') {
            return;
        }
        // Hindari angka nol di depan: "0" + "5" -> "5"
        int start = numberStart();
        if (expr.length() - start == 1 && expr.charAt(start) == '0') {
            if (d == '0') {
                return;
            }
            expr.setLength(expr.length() - 1);
        }
        append(String.valueOf(d));
    }

    private void inputDot() {
        if (justEvaluated) {
            expr.setLength(0);
            justEvaluated = false;
        }
        if (expr.length() == 0 || isOperator(last())) {
            append("0.");
            return;
        }
        if (last() == '%' || last() == '.') {
            return;
        }
        int start = numberStart();
        if (expr.indexOf(".", start) >= 0) {
            return;
        }
        append(".");
    }

    private void inputOperator(char op) {
        justEvaluated = false;
        // Buang operator di belakang supaya operator baru menggantikannya.
        while (expr.length() > 0 && isOperator(last())) {
            expr.setLength(expr.length() - 1);
        }
        if (expr.length() == 0) {
            if (op == '-') {
                append("-");
            }
            return;
        }
        append(String.valueOf(op));
    }

    private void negate() {
        if (expr.length() == 0 || isOperator(last()) || last() == '%') {
            return;
        }
        int start = numberStart();
        if (start > 0 && expr.charAt(start - 1) == '-' && isUnaryMinusAt(start - 1)) {
            expr.deleteCharAt(start - 1);
        } else {
            expr.insert(start, '-');
        }
    }

    private void evaluate() {
        if (expr.length() == 0) {
            return;
        }
        String e = trimTrailingOperators(expr.toString());
        if (e.isEmpty()) {
            return;
        }
        try {
            String result = Calc.evaluate(e);
            expr.setLength(0);
            expr.append(result);
            justEvaluated = true;
        } catch (Calc.CalcException ex) {
            error = ex.getMessage();
        }
    }

    // ---------------------------------------------------------------- bantu

    private char last() {
        return expr.charAt(expr.length() - 1);
    }

    private void append(String s) {
        if (expr.length() + s.length() <= MAX_LENGTH) {
            expr.append(s);
        }
    }

    private static boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    /** Indeks awal angka terakhir di ekspresi (tidak termasuk tanda minus). */
    private int numberStart() {
        int i = expr.length();
        while (i > 0 && (isDigit(expr.charAt(i - 1)) || expr.charAt(i - 1) == '.')) {
            i--;
        }
        return i;
    }

    /** Minus di posisi i adalah tanda negatif (bukan pengurangan) bila di awal atau setelah operator. */
    private boolean isUnaryMinusAt(int i) {
        return i == 0 || isOperator(expr.charAt(i - 1));
    }

    private static String trimTrailingOperators(String s) {
        int end = s.length();
        while (end > 0 && isOperator(s.charAt(end - 1))) {
            end--;
        }
        return s.substring(0, end);
    }

    private static String pretty(String s) {
        return s.replace('*', '×')
                .replace('/', '÷')
                .replace('-', '−')
                .replace('.', ',');
    }

    private void refresh() {
        exprView.setText(expr.length() == 0 ? "0" : pretty(expr.toString()));

        if (error != null) {
            previewView.setTextColor(COLOR_ERROR);
            previewView.setText(error);
            return;
        }
        previewView.setTextColor(COLOR_MUTED);
        previewView.setText("");
        if (justEvaluated || expr.length() == 0) {
            return;
        }
        // Pratinjau hasil sementara bila sudah ada operator selain minus di depan.
        String e = trimTrailingOperators(expr.toString());
        boolean hasOperator = false;
        for (int i = 0; i < e.length(); i++) {
            char c = e.charAt(i);
            if ((isOperator(c) && !(c == '-' && isUnaryMinusAt(i))) || c == '%') {
                hasOperator = true;
                break;
            }
        }
        if (!hasOperator) {
            return;
        }
        try {
            previewView.setText("= " + pretty(Calc.evaluate(e)));
        } catch (Calc.CalcException ignored) {
            // Ekspresi belum lengkap; kosongkan pratinjau.
        }
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }
}

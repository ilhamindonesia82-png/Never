package id.kalkulator.app;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Penghitung ekspresi sederhana: + - * / %, minus unary.
 * Memakai BigDecimal supaya 0.1 + 0.2 = 0.3 (bukan 0.30000000000000004).
 * Persen: "50%" = 0.5, "200+10%" = 220, "200-10%" = 180.
 */
final class Calc {

    static final class CalcException extends Exception {
        CalcException(String message) {
            super(message);
        }
    }

    private static final MathContext MC = new MathContext(20, RoundingMode.HALF_UP);
    private static final MathContext OUT = new MathContext(15, RoundingMode.HALF_UP);

    private final String s;
    private int pos = 0;
    /** True jika suku terakhir yang di-parse berupa satu angka berpersen (mis. "10%"). */
    private boolean pct = false;

    private Calc(String s) {
        this.s = s;
    }

    /** Menghitung ekspresi dan mengembalikan hasil sebagai teks desimal biasa (tanpa notasi ilmiah). */
    static String evaluate(String expr) throws CalcException {
        Calc c = new Calc(expr);
        BigDecimal v = c.parseExpr();
        if (c.pos != c.s.length()) {
            throw new CalcException("Format salah");
        }
        return format(v);
    }

    static String format(BigDecimal v) {
        BigDecimal r = v.round(OUT);
        if (r.signum() == 0) {
            return "0";
        }
        return r.stripTrailingZeros().toPlainString();
    }

    private BigDecimal parseExpr() throws CalcException {
        BigDecimal v = parseTerm();
        while (pos < s.length()) {
            char c = s.charAt(pos);
            if (c != '+' && c != '-') {
                break;
            }
            pos++;
            BigDecimal r = parseTerm();
            if (pct) {
                r = v.multiply(r, MC); // 200 + 10% -> 200 + (200 * 0.1)
            }
            v = (c == '+') ? v.add(r, MC) : v.subtract(r, MC);
        }
        return v;
    }

    private BigDecimal parseTerm() throws CalcException {
        BigDecimal v = parseUnary();
        boolean onlyPct = pct;
        while (pos < s.length()) {
            char c = s.charAt(pos);
            if (c != '*' && c != '/') {
                break;
            }
            pos++;
            BigDecimal r = parseUnary();
            if (c == '*') {
                v = v.multiply(r, MC);
            } else {
                if (r.signum() == 0) {
                    throw new CalcException("Tidak bisa dibagi 0");
                }
                v = v.divide(r, MC);
            }
            onlyPct = false;
        }
        pct = onlyPct;
        return v;
    }

    private BigDecimal parseUnary() throws CalcException {
        if (pos < s.length() && s.charAt(pos) == '-') {
            pos++;
            return parseUnary().negate();
        }
        return parsePostfix();
    }

    private BigDecimal parsePostfix() throws CalcException {
        BigDecimal v = parseNumber();
        boolean hasPct = false;
        while (pos < s.length() && s.charAt(pos) == '%') {
            pos++;
            v = v.divide(BigDecimal.valueOf(100), MC);
            hasPct = true;
        }
        pct = hasPct;
        return v;
    }

    private BigDecimal parseNumber() throws CalcException {
        int start = pos;
        while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) {
            pos++;
        }
        if (start == pos) {
            throw new CalcException("Format salah");
        }
        try {
            return new BigDecimal(s.substring(start, pos));
        } catch (NumberFormatException e) {
            throw new CalcException("Format salah");
        }
    }
}
